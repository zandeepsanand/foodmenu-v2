import React, { useState, useEffect } from "react";
import Card from "react-bootstrap/Card";
import FoodItemList from "./FoodItemList";

export default function FoodItemsSmall() {
  const [foods, setFood] = useState([]);

  const fetchFoodItem = async () => {
    const data = await fetch(
      `http://qrorder.co.in/Jarjeer/public/api/alldata`,
      {
        method: "get",
        headers: new Headers({
          "user-agent": "Mozilla/4.0 MDN Example",
          "content-type": "application/json",
        }),
      }
    );
    // console.log(data);

    const jsonData = await data.json();
    // setPizza(jsonData);

    setFood(jsonData.data);
  };
  useEffect(() => {
    fetchFoodItem();
    // AOS.init();
    // AOS.refresh();
  }, []);
  const products = [
    {
      id: 1,
      name: "Chicken Biriyani",
      price: 299,
      quantity: 1,
      image:
        "https://www.ruchiskitchen.com/wp-content/uploads/2015/05/Chicken-biryani-recipe-2-500x500.jpg",
    },
    {
      id: 2,
      name: "Shavarma",
      price: 299,
      quantity: 1,
      image:
        "https://www.ruchiskitchen.com/wp-content/uploads/2015/05/Chicken-biryani-recipe-2-500x500.jpg",
    },
    {
      id: 3,
      name: "Halwa",
      price: 199,
      quantity: 1,
      image:
        "https://www.ruchiskitchen.com/wp-content/uploads/2015/05/Chicken-biryani-recipe-2-500x500.jpg",
    },
  ];

  return (
    <div>
      
      
        {products
          ? products.map((food) => {
      return(
<Card.Title className=" heading-color">Menu</Card.Title>
<div class="row">
        <FoodItemList food={food} />
        </div>
      ) 
            })
          : ""}
      
    </div>
  );
}
